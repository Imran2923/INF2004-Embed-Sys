// main.c — SD card interactive file reader (type a filename to read)
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "pico/stdlib.h"
#include "ff.h"   // FatFs API

static void list_dir(const char *path) {
    FRESULT fr;
    DIR dir;
    FILINFO fno;
    fr = f_opendir(&dir, path);
    if (fr != FR_OK) { printf("opendir %s err=%d\n", path, fr); return; }
    printf("\nListing %s:\n", path);
    for (;;) {
        fr = f_readdir(&dir, &fno);
        if (fr != FR_OK || fno.fname[0] == 0) break;
        if (strcmp(fno.fname, ".") == 0 || strcmp(fno.fname, "..") == 0) continue;
        printf("%c %10lu  %s\n",
               (fno.fattrib & AM_DIR) ? 'D' : 'F',
               (unsigned long)fno.fsize,
               fno.fname);
    }
    f_closedir(&dir);
}

// Simple line input from USB serial with timeout (ms)
static int read_line(char *buf, size_t cap, uint32_t timeout_ms) {
    size_t i = 0;
    absolute_time_t deadline = make_timeout_time_ms(timeout_ms);
    while (i + 1 < cap) {
        int ch = getchar_timeout_us(50 * 1000); // poll every 50ms
        if (ch == PICO_ERROR_TIMEOUT) {
            if (absolute_time_diff_us(get_absolute_time(), deadline) <= 0) break;
            continue;
        }
        if (ch == '\r' || ch == '\n') break;
        buf[i++] = (char)ch;
    }
    buf[i] = '\0';
    return (int)i;
}

int main() {
    stdio_init_all();
    setvbuf(stdout, NULL, _IONBF, 0);   // unbuffered printf
    sleep_ms(1500);                     // let USB enumerate
    printf("\nSD Card Interactive Read — Maker Pi Pico(W)\n");

    FATFS fs;
    FRESULT fr = f_mount(&fs, "0:", 1);
    if (fr != FR_OK) {
        printf("f_mount error: %d\n", fr);
        while (1) tight_loop_contents();
    }
    printf("Mounted SD card.\n");

    const char *dirpath = "0:/pico_test";
    f_mkdir(dirpath); // ok if already exists

    // Show what's currently on the card (including files you added from PC)
    list_dir(dirpath);

    // Ask user which file to read
    char name[96];
    printf("\nType a filename to read (e.g., hello.txt). Leave blank for 'hello.txt'.\n> ");
    int len = read_line(name, sizeof name, 60000); // 60s
    if (len <= 0) strcpy(name, "hello.txt");

    // Basic sanity: disallow path separators to keep within dirpath
    if (strchr(name, '/') || strchr(name, '\\')) {
        printf("Please provide a simple filename without path separators.\n");
        goto done;
    }

    // Build full path and open read-only (will NOT overwrite your PC edits)
    char filepath[160];
    snprintf(filepath, sizeof filepath, "%s/%s", dirpath, name);

    FIL file; UINT br; char buffer[256];
    fr = f_open(&file, filepath, FA_READ);
    if (fr != FR_OK) {
        printf("Failed to open %s (error %d)\n", filepath, fr);
        goto done;
    }

    printf("\n--- File Contents: %s ---\n", filepath);
    do {
        fr = f_read(&file, buffer, sizeof(buffer) - 1, &br);
        if (fr != FR_OK) { printf("Read error: %d\n", fr); break; }
        buffer[br] = '\0';
        printf("%s", buffer);
    } while (br > 0);
    printf("\n--- End of File ---\n");

    f_close(&file);

done:
    f_unmount("0:");
    printf("Done. You can safely remove the SD card.\n");
    while (1) tight_loop_contents();
}
